import ctypes

print('Hello', ctypes.__name__)
